import React, { useState } from 'react';

export default function Form(props) {
    const [inputName, setInputName] = useState();
    const [inputEmail, setInputEmail] = useState();
    const [inputPassword, setInputPassword] = useState();

    function handleSubmit(event) {
        event.preventDefault();

        clearFields();
    }

    function clearFields() {
        setInputEmail('');
        setInputName('');
        setInputPassword('');
    }

    return (
        <div>
            <form onSubmit={handleSubmit} className="form-form-container was-validated animate__animated animate__fadeInDown">
                <p className='form-title-output'>{props.title}</p>
                <div class="form-floating mb-3">
                    <input
                        type="text"
                        className="form-control"
                        placeholder="Name"
                        required
                        minLength={5}
                        maxLength={45}
                        value={inputName}
                        onChange={(event) => setInputName(event.target.value)}
                    />
                    <label for="floatingInput">Username</label>
                    <div class="valid-feedback animate__animated animate__fadeInDown">Looks good!</div>
                    <div class="invalid-feedback animate__animated animate__fadeInDown">Invalid field.</div>
                </div>

                <div class="form-floating mb-3">
                    <input
                        type="email"
                        className="form-control"
                        placeholder="E-Mail"
                        required
                        minLength={4}
                        maxLength={60}
                        value={inputEmail}
                        onChange={(event) => setInputEmail(event.target.value)}
                    />
                    <label for="floatingInput">E-Mail</label>
                    <div class="valid-feedback animate__animated animate__fadeInDown">Looks good!</div>
                    <div class="invalid-feedback animate__animated animate__fadeInDown">Invalid field.</div>
                </div>

                <div class="form-floating mb-3">
                    <input
                        type="password"
                        className="form-control"
                        placeholder="Password"
                        required
                        minLength={4}
                        maxLength={45}
                        value={inputPassword}
                        onChange={(event) => setInputPassword(event.target.value)}
                    />
                    <label for="floatingInput">Password</label>
                    <div class="valid-feedback animate__animated animate__fadeInDown">Looks good!</div>
                    <div class="invalid-feedback animate__animated animate__fadeInDown">Invalid field.</div>
                </div>

                <div className="d-grid gap-2">
                    <button type="submit" className="btn btn-primary">
                        <strong>Create account</strong>
                    </button>
                </div>
        
                <br/>
                <p className='form-text-alredy animate__animated animate__fadeInDown'>{props.content}&nbsp;<strong className='form-text-alredy-sign-in'>{props.link}</strong></p>
            </form>
        </div>
    );
}