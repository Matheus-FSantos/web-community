import React from 'react';

import './Header.css';

export default function Header() {
    return(
        <div className='header-main-container'>
            <p className='header-title'>4Chat</p>
        </div>
    );
}