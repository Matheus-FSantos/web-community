import React from 'react';

/* CSS Archives */
import './App.css';
import SignIn from './pages/SignIn/SignIn';

/* Components */
import SignUp from './pages/SignUp/SignUp';


function App() {
  return (
    <div className='app-main-container'>
      <SignUp />
      <br/><br/><br/><br/><br/><br/><br/>
      <SignIn />
      <br/><br/><br/><br/><br/><br/><br/>
    </div>
  );
}

export default App;
