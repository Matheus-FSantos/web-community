import React from 'react';

/* Components */
import Form from "../../components/Form/SignIn/Form";

/* CSS Archives */
import './SignIn.css';

export default function SignIn() {
    const images = ['https://img.freepik.com/free-vector/abstract-background-with-3d-pattern_1319-68.jpg?w=826&t=st=1683852435~exp=1683853035~hmac=b59f99664ec733db71f54fbd9e3458fbeac11afcd2eccad24ddc22c0b8efa5e4', 'https://img.freepik.com/free-photo/modern-background-with-geometrical-shapes_23-2148811486.jpg?w=1380&t=st=1683854180~exp=1683854780~hmac=30786aa673df7db778d57041aea00618f0e26321bb0b36836dbaa718e8eb03d2', 'https://img.freepik.com/free-photo/high-angle-creative-background-with-grey-shapes_23-2148811502.jpg?w=1380&t=st=1683854144~exp=1683854744~hmac=7fd6012a4ba7da1551695763dc9265d15f52361096ca401aa1f1cdc8c2869fee', 'https://img.freepik.com/free-photo/3d-elegant-geometrical-texture-background_23-2149073281.jpg?w=1380&t=st=1683854675~exp=1683855275~hmac=ca89952cd58a451968ccb6cea717611d991cab3ddc07cad5c6ec61429d679ff1'];

    return(
        <div className="form-main-container">
            <img className='form-image-output animate__animated animate__fadeInDown' src={images[3]} alt="Form Image"/>

            <Form title="Sign in to your account" content="Not registered?" link="Join us"/>
        </div>
    );
}