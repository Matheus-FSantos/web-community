package br.com.senacsp.projetointegrador;

public class CRUDApplication {

	public static void main(String[] args) {
		new App().init();
	}
	
}
